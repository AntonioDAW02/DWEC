//Antonio Garcia Montes
//U1T3

var op1 = 10 == 10;
var op2 = 10 === 10;
var op3 = 10 === 10.0;
var op4 = "Laura" == "Laura";
var op5 = "Laura" > "Laura";
var op6 = "Laura" < "Laura";
var op7 = "123" == 123;
var op8 = "123" === 123;
var op9 = parseInt("123") > 123;

alert("La operación 10 == 10 es " + op1);
alert("La operación 10 === 10 es " + op2);
alert("La operación 10 === 10.0 es " + op3);
alert("La operación 'Laura' == 'Laura' es " + op4);
alert("La operación 'Laura' > 'Laura' es " + op5);
alert("La operación 'Laura' < 'Laura' es " + op6);
alert("La operación '123' == 123 es " + op7);
alert("La operación '123' === 123 es " + op8);
alert("La operación parseInt('123') es " + op9);