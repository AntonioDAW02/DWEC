var v1 = 1357
v2 = 1357.0
v3 = 135e7
v4 = 01357
v5 = 0x1357

alert("Numero entero: " + v1);
alert("Numero decimal: " + v2);
alert("Numero científico: " + v3);
alert("Numero octal: " + v4);
alert("Numero hexadecimal: " + v5);