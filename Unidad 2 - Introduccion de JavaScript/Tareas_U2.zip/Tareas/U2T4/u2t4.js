var var1 = prompt("¿Está seguro de que quiere hacer esto?");

console.log("Hola " + var1);