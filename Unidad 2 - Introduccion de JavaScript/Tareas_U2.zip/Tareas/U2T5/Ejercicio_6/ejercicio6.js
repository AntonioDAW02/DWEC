var dia = prompt("Introduce un dia de la semana");

switch (dia) {
    case "lunes":
        console.log("Mañana sera Martes");
        break;
    case "martes":
        console.log("Mañana sera Miercoles");
        break;
    case "miercoles":
        console.log("Mañana sera Jueves");
        break;
    case "jueves":
        console.log("Mañana sera Viernes");
        break;
    case "viernes":
        console.log("Mañana sera Sabado");
        break;
    case "sabado":
        console.log("Mañana sera Domingo");
        break;
    case "domingo":
        console.log("Mañana sera Lunes");
        break;
    default:
        break;
}