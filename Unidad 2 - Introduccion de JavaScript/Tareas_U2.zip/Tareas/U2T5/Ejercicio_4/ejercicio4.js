/**
 * Ejecutar el código del archivo calificación.html y evaluar los valores obtenidos. 

 * ¿Qué calificación obtenemos cuando la nota introducida es 5? Y ¿Cuándo es 9? ¿y 2?. 
 * Usar el archivo calificación.html subido al AulaVirtual.
 */

/**
  * Respuesta:
  * 1) cuando la nota introducida es 5 nos sale: 
  *     Aprobado
        Notable
        Sobresaliente
        Valor erroneo

        Es decir todos los resultados que saldrian por encima del 5,
        debido a que el caso 5, no devuelve ningun resultado.
    
        2) cuando la nota introducida es 9 nos sale:
            valor erroneo.

            Nos devuelve "valor erroneo" porque no existe ningun caso para el 9, 
            y se va directamente al caso "default".

        3) Cuando la nota introducida es 2 nos sale:
            valor erroneo.

            Nos devuelve "valor erroneo" porque no existe ningun caso para el 2, 
            y se va directamente al caso "default".
  */