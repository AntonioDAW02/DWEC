var texto = "ejemplo";

var x;
for (texto in texto) {
    texto += texto[x] + " ";
}

console.log(texto);