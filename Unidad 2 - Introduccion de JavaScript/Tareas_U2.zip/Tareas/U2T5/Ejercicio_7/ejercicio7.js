var var1 = "125 / 8 = ";
var var2 = "40 x 4 = ";
var var3 = "25 / 2 = ";
var var4 = "10 x 16 = ";

console.log(var1 + (125 >> 3));
console.log(var2 + (40 << 2));
console.log(var3 + (25 >> 1));
console.log(var4 + (10 << 4));